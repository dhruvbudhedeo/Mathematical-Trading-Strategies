Daily Returns, Cumulative Returns, Max Drawdowns, the Sharpe Ratio, and Sortino Ratio for 5 different equities and international indices
