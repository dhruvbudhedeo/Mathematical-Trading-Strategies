# Mathematical-Trading-Strategies
Official repo for submission of assignments in Mathematical Trading Strategies
